from . import Tac as RealTac

Tac = RealTac